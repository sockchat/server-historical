<?php
namespace sockchat;
require __DIR__ ."/vendor/autoload.php";
use \Ratchet\MessageComponentInterface;
use \Ratchet\ConnectionInterface;
use \Ratchet\Server\IoServer;
use \Ratchet\Http\HttpServer;
use \Ratchet\WebSocket\WsServer;
use \SQLite3;

require_once("lib/constants.php");
require_once("config.php");
require_once("lib/utils.php");
require_once("lib/db.php");
require_once("lib/user.php");
require_once("lib/context.php");
require_once("lib/channel.php");
require_once("lib/msg.php");

require "commands/generic_cmd.php";
foreach(glob("commands/*.php") as $fn) {
    if($fn != "commands/generic_cmd.php")
        include($fn);
}

class Database {
    static protected $conn;

    static public function init() {
        if(file_exists("chat.db"))
            Database::$conn = new SQLite3("chat.db");
        else {
            Database::$conn = new SQLite3("chat.db");
            Database::$conn->query("CREATE TABLE `logs` (`id` INTEGER PRIMARY KEY AUTOINCREMENT,`timestamp` INTEGER,`username` TEXT,`message` TEXT);CREATE TABLE `bans` (`uid` INTEGER,`username` TEXT,`ip` TEXT,`expiration` INTEGER);");
        }
    }

    static public function query($str) {
        return Database::$conn->query($str);
    }

    static public function logMessage($time, $username, $msg) {
        Database::query("INSERT INTO `logs` (`timestamp`, `username`, `message`) VALUES (". $time .", '". $username ."','". $msg ."')");
    }

    //static public function
}

class Chat implements MessageComponentInterface {
    public function __construct() {
        $GLOBALS["auth_method"][0] = $GLOBALS["chat"]["CAUTH_FILE"];
        Utils::$chat = $GLOBALS["chat"];
        Message::$bot = new User("-1", "", "bot", "inherit", "", null);
        Context::CreateChannel(new Channel(Utils::$chat["DEFAULT_CHANNEL"]));

        Utils::PackMessage(0, ["garbage","parms","hi mom"]);

        echo "Server started.\n";
    }

    public function onOpen(ConnectionInterface $conn) {
        Context::CheckPings();
    }

    public function onMessage(ConnectionInterface $conn, $msg) {
        Context::CheckPings();
        if(substr(Utils::GetHeader($conn, "Origin"), -strlen(Utils::$chat["HOST"])) == Utils::$chat["HOST"]) {
            $parts = explode(Utils::$separator, $msg);
            $id = $parts[0];
            $parts = array_slice($parts, 1);

            switch($id) {
                case 0:
                    if(($u = Context::GetUserByID($parts[0])) != null) {
                        $u->ping = gmdate("U");
                        $conn->send(Utils::PackMessage(0, array("pong")));
                    }
                    break;
                case 1:
                    if(!Context::DoesSockExist($conn)) {
                        $arglist = "";
                        for($i = 0; $i < count($parts); $i++)
                            $arglist .= ($i==0?"?":"&") ."arg". ($i+1) ."=". urlencode($parts[$i]);
                        $aparts = file_get_contents(Utils::$chat['CHATROOT'] ."/auth/". $GLOBALS['auth_method'][Utils::$chat['AUTH_TYPE']] . $arglist);

                        if(substr($aparts, 0, 3) == "yes") {
                            $aparts = explode("\n", substr($aparts, 3));
                            if(($reason = Context::AllowUser($aparts[1], $conn)) == 0) {
                                if(($length = Context::CheckBan(Utils::$chat["AUTOID"] ? "NaN" : $aparts[0], $conn->remoteAddress, Utils::Sanitize($aparts[1]))) == 0) {
                                    $id = 0;
                                    if(Utils::$chat["AUTOID"]) {
                                        for($i = 1;; $i++) {
                                            if(Context::GetUserByID($i) == null) {
                                                $id = "".$i;
                                                break;
                                            }
                                        }
                                    } else $id = $aparts[0];

                                    Context::Join(new User($id, Utils::$chat["DEFAULT_CHANNEL"], Utils::Sanitize($aparts[1]), $aparts[2], $aparts[3], $conn));
                                } else $conn->send(Utils::PackMessage(1, array_key_exists("n", "3", $length)));
                            } else $conn->send(Utils::PackMessage(1, array("n", $reason)));
                        } else $conn->send(Utils::PackMessage(1, array("n", "0")));
                    }
                    break;
                case 2:
                    if(($user = Context::GetUserByID($parts[0])) != null) {
                        if($user->sock == $conn) {
                            if(trim($parts[1]) != "" && strlen(trim($parts[1])) <= Utils::$chat["MAX_MSG_LEN"]) {
                                if(trim($parts[1])[0] != "/") {
                                    Message::BroadcastUserMessage($user, Utils::Sanitize($parts[1]));
                                } else {
                                    $parts[1] = substr(trim($parts[1]), 1);
                                    $cmdparts = explode(" ", $parts[1]);
                                    $cmd = str_replace(".","",$cmdparts[0]);
                                    $cmdparts = array_slice($cmdparts, 1);
                                    for($i = 0; $i < count($cmdparts); $i++)
                                        $cmdparts[$i] = Utils::Sanitize($cmdparts[$i]);

                                    if(strtolower($cmd) != "generic_cmd" && file_exists("commands/". strtolower($cmd) .".php")) {
                                        try {
                                            call_user_func_array("\\sockchat\\cmds\\". strtolower($cmd) ."::doCommand", [$user, $cmdparts]);
                                        } catch(\Exception $err) {
                                            Message::BroadcastBotMessage(MSG_ERROR, "cmderr", [strtolower($cmd), $err->getMessage()]);
                                        }
                                    } else
                                        Message::PrivateBotMessage(MSG_ERROR, "nocmd", [strtolower($cmd)], $user);
                                        //echo "got here";
                                }
                            }
                        }
                    }
                    break;
            }
        } else
            $conn->close();
    }

    public function onClose(ConnectionInterface $conn) {
        echo $conn->remoteAddress ." has disconnected\n";
        foreach(Context::$onlineUsers as $user) {
            if($user->sock == $conn) {
                echo "found user ". $user->username .", dropped\n";
                Context::Leave($user);
            }
        }
        Context::CheckPings();
    }

    public function onError(ConnectionInterface $conn, \Exception $err) {
        Context::CheckPings();
        echo "Error on ". $conn->remoteAddress .": ". $err ."\n";
    }
}

$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new Chat()
        )
    ),
    $GLOBALS["chat"]["PORT"]
);

$server->run();