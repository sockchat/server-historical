<?php
define("AUTH_CUSTOM", 0);
define("AUTH_PHPBB", 1);

$auth_method = array("", "phpbb.php");