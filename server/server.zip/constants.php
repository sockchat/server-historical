<?php
define("AUTH_CUSTOM", 0);
define("AUTH_PHPBB", 1);

$auth_method = array("", "phpbb.php");

define("MSG_NORMAL", 0);
define("MSG_ERROR", 1);