<?php
namespace sockchat\cmds;
use sockchat\cmds\GenericCommand;

class kick implements GenericCommand {
    public static function doCommand($user, $args) {
        /*$foundUser = null;
        foreach($chat->connectedUsers as $u) {
            if(strtolower($u) == strtolower($arr[0])) {
                $foundUser = $u;
                break;
            }
        }

        if($foundUser == null)
            $chat->SendMessage($chat->chatbot, $user, "<i><span style='color: red;'>Error: User ". $arr[0] ." not found.</span></i>");
        else {

        }
        $chat->BroadcastMessage($chat->chatbot, "<a href='http://aroltd.com'>hello</a>");*/
    }
}